@echo off
echo ====================================
echo   Readify - Docker Production Mode
echo ====================================
echo.
echo PostgreSQL ve App konteynerleri hazirlanir...
echo.

REM Start containers in detached mode
docker-compose up -d --build

echo.
echo ====================================
echo   UĞURLU! Sistem arxa planda işə düşdü
echo ====================================
echo.
echo Gözləyin, brauzer açılır...
timeout /t 10 >nul
start http://localhost:8081
start http://localhost:8080

echo.
echo === Faydalı Linklər ===
echo App:            http://localhost:8081
echo Database (GUI): http://localhost:8080
echo Loglari gormek:     docker-compose logs -f
echo Dayandirmaq:        docker-compose down
echo Restart:            docker-compose restart
echo.
pause