package com.kitabxana.backend.cli;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Console runner is deprecated in favor of Web UI.
 */
@Component
public class ConsoleRunner implements CommandLineRunner {

    @Override
    public void run(String... args) throws Exception {
        System.out.println("=== Kitabxana Backend Started ===");
        System.out.println("Console CLI is deprecated. Please use the Web UI at http://localhost:8080");
    }
}