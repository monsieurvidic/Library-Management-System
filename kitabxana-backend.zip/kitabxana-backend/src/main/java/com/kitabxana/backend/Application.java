package com.kitabxana.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Boot application entry.
 */
@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @org.springframework.context.event.EventListener(org.springframework.boot.context.event.ApplicationReadyEvent.class)
    public void openBrowser() {
        System.out.println("Tətbiq işə düşdü! Brauzer açılır...");
        try {
            String url = "http://localhost:8081";
            if (java.awt.Desktop.isDesktopSupported()) {
                java.awt.Desktop desktop = java.awt.Desktop.getDesktop();
                if (desktop.isSupported(java.awt.Desktop.Action.BROWSE)) {
                    desktop.browse(new java.net.URI(url));
                }
            } else {
                // Windows fallback using ProcessBuilder
                new ProcessBuilder("rundll32", "url.dll,FileProtocolHandler", url).start();
            }
        } catch (Exception e) {
            System.err.println("Brauzeri avtomatik açmaq mümkün olmadı: " + e.getMessage());
            System.out.println("Zəhmət olmasa bu linkə daxil olun: http://localhost:8081");
        }
    }
}