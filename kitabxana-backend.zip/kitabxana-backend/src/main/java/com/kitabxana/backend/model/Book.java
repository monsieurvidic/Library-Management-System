package com.kitabxana.backend.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

/**
 * Book model as a JPA Entity.
 */
@Entity
@Table(name = "books")
public class Book {

    @Id
    @Column(length = 50)
    private String id; // Internal id (B000001 etc)

    @NotBlank
    private String isbn; // Realistic ISBN

    @NotBlank
    private String title;

    @NotBlank
    private String author;

    private String genre;

    @Column(name = "publication_year")
    private int year;

    // Stock management
    @Column(name = "stock", columnDefinition = "integer default 1")
    private int stock = 1;

    @Column(name = "available", columnDefinition = "boolean default true")
    private boolean available;

    @Column(name = "total_borrow_count", columnDefinition = "integer default 0")
    private int totalBorrowCount;

    @Column(name = "search_count", columnDefinition = "integer default 0")
    private int searchCount;

    private String imageUrl;

    // Default constructor for JPA
    public Book() {
    }

    public Book(String id, String isbn, String title, String author, String genre, int year) {
        this(id, isbn, title, author, genre, year, 1);
    }

    public Book(String id, String isbn, String title, String author, String genre, int year, int stock) {
        this.id = id;
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.year = year;
        this.stock = stock;
        this.available = stock > 0;
        // Construct image URL from ISBN if not provided
        if (this.imageUrl == null || this.imageUrl.isEmpty()) {
            this.imageUrl = String.format("https://covers.openlibrary.org/b/isbn/%s-L.jpg", isbn);
        }
    }

    // Getters / Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
        // Update image URL if ISBN changes
        this.imageUrl = String.format("https://covers.openlibrary.org/b/isbn/%s-L.jpg", isbn);
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public boolean isAvailable() {
        return stock > 0;
    }

    // Keep getter for backwards compatibility if needed, but logic is driven by
    // stock
    public boolean getAvailable() {
        return isAvailable();
    }

    // Removed setAvailable - stock-based logic used instead

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getSearchCount() {
        return searchCount;
    }

    public void setSearchCount(int searchCount) {
        this.searchCount = searchCount;
    }

    // Domain actions
    public synchronized void markAsBorrowed() {
        if (stock <= 0)
            throw new IllegalStateException("Kitab bitmişdir.");

        this.stock--;
        this.totalBorrowCount++;
    }

    public synchronized void markAsReturned() {
        this.stock++;
    }

    public void increaseSearchCount() {
        this.searchCount++;
    }

    @JsonIgnore
    public String shortInfo() {
        return String.format("[%s] %s | %s | %s | %d | Stok: %d",
                id, title, author, genre, year, stock);
    }
}