package com.kitabxana.backend.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

/**
 * Simple librarian/admin user.
 */
@Entity
@DiscriminatorValue("LIBRARIAN")
public class Librarian extends User {

    public Librarian() {
    }

    public Librarian(String id, String name, String surname, String password) {
        super(id, name, surname, password);
    }

    @Override
    public String getRole() {
        return "LIBRARIAN";
    }
}