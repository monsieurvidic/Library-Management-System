package com.kitabxana.backend.repository;

import com.kitabxana.backend.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;

public interface BookRepository extends JpaRepository<Book, String> {
    Optional<Book> findByIsbn(String isbn);

    @Query("SELECT MAX(b.id) FROM Book b")
    String findMaxId();
}