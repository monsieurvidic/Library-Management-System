package com.kitabxana.backend.repository;

import com.kitabxana.backend.model.Loan;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;

public interface LoanRepository extends JpaRepository<Loan, String> {
    List<Loan> findByReturnDateIsNull();

    @Query("SELECT MAX(l.id) FROM Loan l")
    String findMaxId();
}
