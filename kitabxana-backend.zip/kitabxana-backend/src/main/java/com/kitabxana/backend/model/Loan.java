package com.kitabxana.backend.model;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 * Loan record for a borrowed book.
 */
@Entity
@Table(name = "loans")
public class Loan {

    @Id
    @Column(length = 50)
    private String loanId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "book_id")
    private Book book;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "member_id")
    private Member member;

    private LocalDate loanDate;
    private LocalDate dueDate;
    private LocalDate returnDate;

    private static final int DEFAULT_LOAN_PERIOD_DAYS = 14;

    public Loan() {
    }

    public Loan(String loanId, Book book, Member member) {
        this.loanId = loanId;
        this.book = book;
        this.member = member;
        this.loanDate = LocalDate.now();
        this.dueDate = loanDate.plusDays(DEFAULT_LOAN_PERIOD_DAYS);
        this.returnDate = null;
    }

    // Getters / Setters
    public String getLoanId() {
        return loanId;
    }

    public void setLoanId(String loanId) {
        this.loanId = loanId;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    // Helper for backward compatibility/DTO
    public String getBookId() {
        return book != null ? book.getId() : null;
    }

    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    // Helper for backward compatibility/DTO
    public String getMemberId() {
        return member != null ? member.getId() : null;
    }

    public LocalDate getLoanDate() {
        return loanDate;
    }

    public void setLoanDate(LocalDate loanDate) {
        this.loanDate = loanDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public void markAsReturned() {
        if (this.returnDate == null) {
            this.returnDate = LocalDate.now();
        }
    }

    public boolean isOverdue() {
        return returnDate == null && LocalDate.now().isAfter(dueDate);
    }

    @Override
    public String toString() {
        String status = returnDate == null ? (isOverdue() ? "GECİKMƏDƏ" : "AKTİV") : "QAYTARILIB";
        return String.format("Loan ID: %s | Kitab: %s | Oxucu: %s | Son tarix: %s | Status: %s",
                loanId, getBookId(), getMemberId(), dueDate, status);
    }
}