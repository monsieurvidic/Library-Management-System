package com.kitabxana.backend.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

/**
 * Member (regular library user).
 */
@Entity
@DiscriminatorValue("MEMBER")
public class Member extends User {
    private int totalReadCount;
    private int streak;
    private int bestStreak;

    public Member() {
    }

    public Member(String id, String name, String surname, String password) {
        super(id, name, surname, password);
        this.totalReadCount = 0;
        this.streak = 0;
        this.bestStreak = 0;
    }

    @Override
    public String getRole() {
        return "MEMBER";
    }

    public int getTotalReadCount() {
        return totalReadCount;
    }

    public int getStreak() {
        return streak;
    }

    public int getBestStreak() {
        return bestStreak;
    }

    public void increaseReadCount() {
        this.totalReadCount++;
        this.streak++;
        if (streak > bestStreak)
            bestStreak = streak;
    }

    public void resetStreak() {
        this.streak = 0;
    }

    public String getStatus() {
        return totalReadCount > 10 ? "Kitabqurdu" : "Yeni Oxucu";
    }
}