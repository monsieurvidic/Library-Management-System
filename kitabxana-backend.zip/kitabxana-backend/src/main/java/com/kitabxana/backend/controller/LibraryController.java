package com.kitabxana.backend.controller;

import com.kitabxana.backend.model.*;
import com.kitabxana.backend.service.LibraryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.*;

/**
 * REST API controller for the library backend.
 *
 * CORS is enabled for http://localhost:3000 to be convenient for local React
 * frontend.
 * Adjust origins in production.
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3000")
public class LibraryController {

    private final LibraryService libraryService;

    @Autowired
    public LibraryController(LibraryService libraryService) {
        this.libraryService = libraryService;
    }

    // ---------------- DTOs ----------------
    public static class LoginRequest {
        public String id;
        public String password;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }

    public static class SignUpRequest {
        public String name;
        public String surname;
        public String password;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getSurname() {
            return surname;
        }

        public void setSurname(String surname) {
            this.surname = surname;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }

    public static class LoanRequest {
        public String bookId;
        public String memberId;

        public String getBookId() {
            return bookId;
        }

        public void setBookId(String bookId) {
            this.bookId = bookId;
        }

        public String getMemberId() {
            return memberId;
        }

        public void setMemberId(String memberId) {
            this.memberId = memberId;
        }
    }

    // ---------------- Endpoints ----------------

    // POST /api/auth/login
    @PostMapping("/auth/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        if (request == null || request.getId() == null || request.getPassword() == null) {
            return ResponseEntity.badRequest().body("ID və şifrə daxil edilməyib.");
        }
        User user = libraryService.authenticate(request.getId(), request.getPassword());
        if (user == null) {
            return ResponseEntity.status(401).body("Yanlış ID və ya Şifrə!");
        }
        return ResponseEntity.ok(user);
    }

    // POST /api/auth/signup
    @PostMapping("/auth/signup")
    public ResponseEntity<?> signUp(@RequestBody SignUpRequest request) {
        if (request == null || request.getName() == null || request.getPassword() == null) {
            return ResponseEntity.badRequest().body("Ad və şifrə lazımdır.");
        }
        String newId = libraryService.signUp(request.getName(), request.getSurname(), request.getPassword());
        return ResponseEntity.ok(Map.of("memberId", newId));
    }

    // GET /api/books
    @GetMapping("/books")
    public List<Book> getAllBooks() {
        return libraryService.getAllBooks();
    }

    // POST /api/books/add
    @PostMapping("/books/add")
    public ResponseEntity<?> addBook(@RequestBody Book bookData) {
        if (bookData == null || bookData.getIsbn() == null || bookData.getTitle() == null) {
            return ResponseEntity.badRequest().body("ISBN və Title tələb olunur.");
        }
        String result = libraryService.addBook(
                bookData.getIsbn(), bookData.getTitle(), bookData.getAuthor(),
                bookData.getGenre(), bookData.getYear());
        if (result.startsWith("Xəta")) {
            return ResponseEntity.badRequest().body(result);
        }
        return ResponseEntity.ok(Map.of("bookId", result));
    }

    // GET /api/loans/overdue
    @GetMapping("/loans/overdue")
    public List<Loan> getOverdueLoans() {
        return libraryService.getOverdueLoans();
    }

    // GET /api/loans/active
    @GetMapping("/loans/active")
    public List<Loan> getActiveLoans() {
        return libraryService.getActiveLoans();
    }

    // POST /api/loans/borrow
    @PostMapping("/loans/borrow")
    public ResponseEntity<?> borrowBook(@RequestBody LoanRequest request) {
        if (request == null || request.getBookId() == null || request.getMemberId() == null) {
            return ResponseEntity.badRequest().body("bookId və memberId tələb olunur.");
        }
        String result = libraryService.borrowBook(request.getBookId(), request.getMemberId());
        if (result.startsWith("Xəta")) {
            return ResponseEntity.badRequest().body(result);
        }
        return ResponseEntity.ok(Map.of("loanId", result));
    }

    // POST /api/loans/return
    @PostMapping("/loans/return")
    public ResponseEntity<?> returnBook(@RequestBody LoanRequest request) {
        if (request == null || request.getBookId() == null || request.getMemberId() == null) {
            return ResponseEntity.badRequest().body("bookId və memberId tələb olunur.");
        }
        String result = libraryService.returnBook(request.getBookId(), request.getMemberId());
        if (result.startsWith("Xəta")) {
            return ResponseEntity.badRequest().body(result);
        }
        return ResponseEntity.ok(Map.of("status", result));
    }

    // DELETE /api/users/{id}
    @DeleteMapping("/users/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable String id) {
        try {
            libraryService.deleteUser(id);
            return ResponseEntity.ok(Map.of("message", "Deleted: " + id));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // POST /api/users (Admin Create)
    @PostMapping("/users")
    public ResponseEntity<?> createMember(@RequestBody SignUpRequest request) {
        try {
            String newId = libraryService.createMember(request.getName(), request.getSurname(), request.getPassword(),
                    null);
            return ResponseEntity.ok(Map.of("memberId", newId));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // GET /api/users
    @GetMapping("/users")
    public List<Member> getAllMembers() {
        return libraryService.getAllMembers();
    }

    // DTO for Profile Update
    public static class ProfileUpdateRequest {
        public String id;
        public String name;
        public String surname;
        public String password;
        public String avatarUrl;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getSurname() {
            return surname;
        }

        public void setSurname(String surname) {
            this.surname = surname;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getAvatarUrl() {
            return avatarUrl;
        }

        public void setAvatarUrl(String avatarUrl) {
            this.avatarUrl = avatarUrl;
        }
    }

    // PUT /api/users/{id}
    @PutMapping("/users/{id}")
    public ResponseEntity<?> updateUser(@PathVariable String id, @RequestBody ProfileUpdateRequest request) {
        try {
            User updated = libraryService.updateUserProfile(id, request.getName(), request.getSurname(),
                    request.getPassword(), request.getAvatarUrl());
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // PUT /api/books
    @PutMapping("/books")
    public ResponseEntity<?> updateBook(@RequestBody Book book) {
        if (book.getId() == null) {
            return ResponseEntity.badRequest().body("Book ID tələb olunur.");
        }
        try {
            Book updated = libraryService.updateBook(book.getId(), book.getIsbn(), book.getTitle(),
                    book.getAuthor(), book.getGenre(), book.getYear());
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // DELETE /api/books/{id}
    @DeleteMapping("/books/{id}")
    public ResponseEntity<?> deleteBook(@PathVariable String id) {
        try {
            libraryService.deleteBook(id);
            return ResponseEntity.ok(Map.of("message", "Deleted book: " + id));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // PUT /api/profile
    @PutMapping("/profile")
    public ResponseEntity<?> updateProfile(@RequestBody ProfileUpdateRequest request) {
        if (request == null || request.getId() == null) {
            return ResponseEntity.badRequest().body("User ID tələb olunur.");
        }
        try {
            User updated = libraryService.updateUserProfile(request.getId(), request.getName(), request.getSurname(),
                    request.getPassword(), request.getAvatarUrl());
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}