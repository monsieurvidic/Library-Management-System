package com.kitabxana.backend.repository;

import com.kitabxana.backend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;

public interface UserRepository extends JpaRepository<User, String> {
    @Query("SELECT MAX(u.id) FROM User u WHERE u.id LIKE 'M%'")
    String findMaxMemberId();
}
