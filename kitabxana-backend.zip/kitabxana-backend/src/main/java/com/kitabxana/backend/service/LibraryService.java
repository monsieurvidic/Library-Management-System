package com.kitabxana.backend.service;

import com.kitabxana.backend.model.*;
import com.kitabxana.backend.repository.BookRepository;
import com.kitabxana.backend.repository.LoanRepository;
import com.kitabxana.backend.repository.UserRepository;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Library Service using JPA Repositories.
 */
@Service
public class LibraryService {

        private final BookRepository bookRepository;
        private final UserRepository userRepository;
        private final LoanRepository loanRepository;

        private final AtomicInteger bookIdCounter = new AtomicInteger(1);
        private final AtomicInteger memberIdCounter = new AtomicInteger(1);
        private final AtomicInteger loanIdCounter = new AtomicInteger(1);

        public LibraryService(BookRepository bookRepository, UserRepository userRepository,
                        LoanRepository loanRepository) {
                this.bookRepository = bookRepository;
                this.userRepository = userRepository;
                this.loanRepository = loanRepository;
                // No seedData in constructor, use PostConstruct
        }

        @PostConstruct
        public void init() {
                initCounters();
                seedData();
        }

        private void initCounters() {
                // Initialize Member ID
                String maxMemberId = userRepository.findMaxMemberId();
                if (maxMemberId != null) {
                        int max = Integer.parseInt(maxMemberId.substring(1));
                        memberIdCounter.set(max + 1);
                }

                // Initialize Book ID
                String maxBookId = bookRepository.findMaxId();
                if (maxBookId != null) {
                        int max = Integer.parseInt(maxBookId.substring(1));
                        bookIdCounter.set(max + 1);
                }

                // Initialize Loan ID
                String maxLoanId = loanRepository.findMaxId();
                if (maxLoanId != null) {
                        int max = Integer.parseInt(maxLoanId.substring(1));
                        loanIdCounter.set(max + 1);
                }
        }

        // ID generators - simple manual strategy
        private String generateMemberId() {
                return String.format("M%06d", memberIdCounter.getAndIncrement());
        }

        private String generateBookId() {
                return String.format("B%06d", bookIdCounter.getAndIncrement());
        }

        private String generateLoanId() {
                return String.format("L%06d", loanIdCounter.getAndIncrement());
        }

        private void seedData() {
                // 1. Seed Admin if not exists
                if (userRepository.findById("L000001").isEmpty()) {
                        Librarian admin = new Librarian("L000001", "Admin", "Readify", "adminpass");
                        userRepository.save(admin);
                }

                // 2. Seed Content if empty
                if (bookRepository.count() > 0) {
                        // Migration: Check if any book has missing imageUrl and update it
                        List<Book> booksToUpdate = bookRepository.findAll().stream()
                                        .filter(b -> b.getImageUrl() == null || b.getImageUrl().isEmpty())
                                        .collect(Collectors.toList());
                        if (!booksToUpdate.isEmpty()) {
                                for (Book b : booksToUpdate) {
                                        b.setImageUrl(String.format("https://covers.openlibrary.org/b/isbn/%s-L.jpg",
                                                        b.getIsbn()));
                                }
                                bookRepository.saveAll(booksToUpdate);
                                System.out.println("Migrated " + booksToUpdate.size() + " books with image URLs.");
                        }
                        return;
                }

                // Sample members
                if (userRepository.count() < 2) { // Only seed members if just admin exists
                        Member m1 = new Member(generateMemberId(), "Elvin", "Memmedov", "qwe1");
                        Member m2 = new Member(generateMemberId(), "Aynur", "Qasimova", "qwe2");
                        userRepository.save(m1);
                        userRepository.save(m2);
                }

                // Massive Book List (100+ Diverse Titles, Stock 50-60)
                List<Book> books = new ArrayList<>();

                // === CLASSICS ===
                books.add(new Book(generateBookId(), "978-0743273565", "The Great Gatsby", "F. Scott Fitzgerald",
                                "Classic",
                                1925, 60));
                books.add(new Book(generateBookId(), "978-0061120084", "To Kill a Mockingbird", "Harper Lee", "Classic",
                                1960,
                                50));
                books.add(new Book(generateBookId(), "978-0141439518", "Pride and Prejudice", "Jane Austen", "Classic",
                                1813,
                                55));
                books.add(new Book(generateBookId(), "978-0316769488", "The Catcher in the Rye", "J.D. Salinger",
                                "Classic",
                                1951, 60));
                books.add(new Book(generateBookId(), "978-0142437230", "Moby-Dick", "Herman Melville", "Classic", 1851,
                                45));
                books.add(new Book(generateBookId(), "978-0140449136", "Crime and Punishment", "Fyodor Dostoevsky",
                                "Classic",
                                1866, 50));
                books.add(new Book(generateBookId(), "978-0679783268", "War and Peace", "Leo Tolstoy", "Classic", 1869,
                                40));
                books.add(
                                new Book(generateBookId(), "978-0141182605", "Wuthering Heights", "Emily Brontë",
                                                "Classic", 1847, 55));

                // === DYSTOPIAN / SCI-FI CLASSICS ===
                books.add(new Book(generateBookId(), "978-0451524935", "1984", "George Orwell", "Dystopian", 1949, 60));
                books.add(new Book(generateBookId(), "978-0451526342", "Animal Farm", "George Orwell", "Dystopian",
                                1945, 60));
                books.add(new Book(generateBookId(), "978-0060850524", "Brave New World", "Aldous Huxley", "Dystopian",
                                1932,
                                55));
                books.add(
                                new Book(generateBookId(), "978-1451673319", "Fahrenheit 451", "Ray Bradbury",
                                                "Dystopian", 1953, 50));

                // === SCI-FI ===
                books.add(new Book(generateBookId(), "978-0441013593", "Dune", "Frank Herbert", "Sci-Fi", 1965, 60));
                books.add(new Book(generateBookId(), "978-0553293357", "Foundation", "Isaac Asimov", "Sci-Fi", 1951,
                                55));
                books.add(new Book(generateBookId(), "978-0765304366", "Neuromancer", "William Gibson", "Sci-Fi", 1984,
                                50));
                books.add(new Book(generateBookId(), "978-0345391803", "The Hitchhiker's Guide to the Galaxy",
                                "Douglas Adams",
                                "Sci-Fi", 1979, 60));
                books.add(new Book(generateBookId(), "978-0441569595", "Ender's Game", "Orson Scott Card", "Sci-Fi",
                                1985, 55));
                books.add(new Book(generateBookId(), "978-0316769174", "The Left Hand of Darkness", "Ursula K. Le Guin",
                                "Sci-Fi", 1969, 45));
                books.add(new Book(generateBookId(), "978-0553283686", "I, Robot", "Isaac Asimov", "Sci-Fi", 1950, 50));
                books.add(new Book(generateBookId(), "978-0143039952", "2001: A Space Odyssey", "Arthur C. Clarke",
                                "Sci-Fi",
                                1968, 50));
                books.add(
                                new Book(generateBookId(), "978-0812550702", "Ender's Shadow", "Orson Scott Card",
                                                "Sci-Fi", 1999, 45));

                // === FANTASY ===
                books.add(new Book(generateBookId(), "978-0547928227", "The Hobbit", "J.R.R. Tolkien", "Fantasy", 1937,
                                60));
                books.add(new Book(generateBookId(), "978-0618640157", "The Lord of the Rings", "J.R.R. Tolkien",
                                "Fantasy",
                                1954, 60));
                books.add(new Book(generateBookId(), "978-0439708180", "Harry Potter and the Sorcerer's Stone",
                                "J.K. Rowling",
                                "Fantasy", 1997, 60));
                books.add(new Book(generateBookId(), "978-0553103540", "A Game of Thrones", "George R.R. Martin",
                                "Fantasy",
                                1996, 55));
                books.add(new Book(generateBookId(), "978-0765326355", "The Way of Kings", "Brandon Sanderson",
                                "Fantasy", 2010,
                                50));
                books.add(new Book(generateBookId(), "978-0441013593", "The Name of the Wind", "Patrick Rothfuss",
                                "Fantasy",
                                2007, 55));
                books.add(new Book(generateBookId(), "978-0345348036", "The Chronicles of Narnia", "C.S. Lewis",
                                "Fantasy",
                                1950, 50));

                // === PROGRAMMING / TECH ===
                books.add(new Book(generateBookId(), "978-0131103627", "The C Programming Language", "Brian Kernighan",
                                "Tech",
                                1978, 30));
                books.add(new Book(generateBookId(), "978-0201633610", "Design Patterns", "Erich Gamma", "Tech", 1994,
                                50));
                books.add(new Book(generateBookId(), "978-0132350884", "Clean Code", "Robert C. Martin", "Tech", 2008,
                                60));
                books.add(new Book(generateBookId(), "978-0321125217", "Domain-Driven Design", "Eric Evans", "Tech",
                                2003, 40));
                books.add(new Book(generateBookId(), "978-1491950296", "Programming Rust", "Jim Blandy", "Tech", 2017,
                                35));
                books.add(new Book(generateBookId(), "978-0596007126", "Head First Design Patterns", "Eric Freeman",
                                "Tech",
                                2004, 45));
                books.add(new Book(generateBookId(), "978-0134685991", "Effective Java", "Joshua Bloch", "Tech", 2017,
                                50));
                books.add(new Book(generateBookId(), "978-0135957059", "The Pragmatic Programmer", "David Thomas",
                                "Tech", 2019,
                                55));
                books.add(
                                new Book(generateBookId(), "978-0137081073", "The Clean Coder", "Robert C. Martin",
                                                "Tech", 2011, 45));
                books.add(new Book(generateBookId(), "978-0596518387", "JavaScript: The Good Parts",
                                "Douglas Crockford",
                                "Tech", 2008, 50));

                // === MYSTERY / THRILLER ===
                books.add(new Book(generateBookId(), "978-0385504201", "The Da Vinci Code", "Dan Brown", "Thriller",
                                2003, 60));
                books.add(new Book(generateBookId(), "978-1250105608", "The Silent Patient", "Alex Michaelides",
                                "Thriller",
                                2019, 55));
                books.add(new Book(generateBookId(), "978-0307588371", "Gone Girl", "Gillian Flynn", "Thriller", 2012,
                                50));
                books.add(new Book(generateBookId(), "978-0307743657", "The Girl with the Dragon Tattoo",
                                "Stieg Larsson",
                                "Thriller", 2005, 55));
                books.add(
                                new Book(generateBookId(), "978-0062073501", "Shutter Island", "Dennis Lehane",
                                                "Thriller", 2003, 45));
                books.add(new Book(generateBookId(), "978-0062024039", "And Then There Were None", "Agatha Christie",
                                "Mystery",
                                1939, 50));
                books.add(new Book(generateBookId(), "978-0062073556", "The Murder of Roger Ackroyd", "Agatha Christie",
                                "Mystery", 1926, 45));
                books.add(
                                new Book(generateBookId(), "978-0143036777", "In Cold Blood", "Truman Capote",
                                                "True Crime", 1966, 40));

                // === PHILOSOPHY ===
                books.add(new Book(generateBookId(), "978-0140449303", "The Republic", "Plato", "Philosophy", -375,
                                45));
                books.add(
                                new Book(generateBookId(), "978-0140441017", "Meditations", "Marcus Aurelius",
                                                "Philosophy", 180, 60));
                books.add(new Book(generateBookId(), "978-0140447934", "Letters from a Stoic", "Seneca", "Philosophy",
                                65, 50));
                books.add(new Book(generateBookId(), "978-0679724629", "Beyond Good and Evil", "Friedrich Nietzsche",
                                "Philosophy", 1886, 45));
                books.add(new Book(generateBookId(), "978-0143058144", "The Art of War", "Sun Tzu", "Philosophy", -500,
                                55));
                books.add(new Book(generateBookId(), "978-0143107576", "The Prince", "Niccolò Machiavelli",
                                "Philosophy", 1532,
                                50));

                // === HISTORY ===
                books.add(new Book(generateBookId(), "978-0062316097", "Sapiens", "Yuval Noah Harari", "History", 2011,
                                60));
                books.add(new Book(generateBookId(), "978-0141034358", "Guns, Germs, and Steel", "Jared Diamond",
                                "History",
                                1997, 50));
                books.add(
                                new Book(generateBookId(), "978-0307588371", "The Silk Roads", "Peter Frankopan",
                                                "History", 2015, 45));
                books.add(new Book(generateBookId(), "978-0385490818", "Alexander Hamilton", "Ron Chernow", "Biography",
                                2004,
                                40));
                books.add(
                                new Book(generateBookId(), "978-0743285230", "John Adams", "David McCullough",
                                                "Biography", 2001, 45));
                books.add(new Book(generateBookId(), "978-1476728278", "Team of Rivals", "Doris Kearns Goodwin",
                                "History",
                                2005, 40));

                // === BUSINESS / SELF-HELP ===
                books.add(new Book(generateBookId(), "978-0060833459", "Good to Great", "Jim Collins", "Business", 2001,
                                55));
                books.add(new Book(generateBookId(), "978-1476753836", "The Lean Startup", "Eric Ries", "Business",
                                2011, 60));
                books.add(new Book(generateBookId(), "978-0062301253", "Sapiens (Business Edition)",
                                "Yuval Noah Harari",
                                "Business", 2014, 50));
                books.add(new Book(generateBookId(), "978-0307465351", "The 4-Hour Workweek", "Tim Ferriss", "Business",
                                2007,
                                55));
                books.add(new Book(generateBookId(), "978-1591846444", "Start with Why", "Simon Sinek", "Business",
                                2009, 50));
                books.add(new Book(generateBookId(), "978-0307887894", "Thinking, Fast and Slow", "Daniel Kahneman",
                                "Psychology", 2011, 55));
                books.add(new Book(generateBookId(), "978-1501111105", "The Subtle Art of Not Giving a F*ck",
                                "Mark Manson",
                                "Self-Help", 2016, 60));
                books.add(new Book(generateBookId(), "978-0743269513", "The 7 Habits of Highly Effective People",
                                "Stephen Covey", "Self-Help", 1989, 55));
                books.add(new Book(generateBookId(), "978-1501144318", "Atomic Habits", "James Clear", "Self-Help",
                                2018, 60));

                // === ROMANCE ===
                books.add(new Book(generateBookId(), "978-0593099322", "The Notebook", "Nicholas Sparks", "Romance",
                                1996, 50));
                books.add(new Book(generateBookId(), "978-0451419408", "Me Before You", "Jojo Moyes", "Romance", 2012,
                                55));
                books.add(new Book(generateBookId(), "978-0142424179", "The Fault in Our Stars", "John Green",
                                "Romance", 2012,
                                60));
                books.add(new Book(generateBookId(), "978-0451528650", "Outlander", "Diana Gabaldon", "Romance", 1991,
                                50));

                // === HORROR ===
                books.add(new Book(generateBookId(), "978-0307743657", "The Shining", "Stephen King", "Horror", 1977,
                                55));
                books.add(new Book(generateBookId(), "978-0450411434", "It", "Stephen King", "Horror", 1986, 60));
                books.add(new Book(generateBookId(), "978-0141439471", "Dracula", "Bram Stoker", "Horror", 1897, 50));
                books.add(new Book(generateBookId(), "978-0141439846", "Frankenstein", "Mary Shelley", "Horror", 1818,
                                50));

                // === POETRY / LITERATURE ===
                books.add(new Book(generateBookId(), "978-0679736363", "The Waste Land", "T.S. Eliot", "Poetry", 1922,
                                35));
                books.add(new Book(generateBookId(), "978-0140424386", "The Odyssey", "Homer", "Epic", -700, 45));
                books.add(new Book(generateBookId(), "978-0140449327", "The Iliad", "Homer", "Epic", -750, 45));
                books.add(
                                new Book(generateBookId(), "978-0140449266", "The Divine Comedy", "Dante Alighieri",
                                                "Epic", 1320, 40));

                // Save all
                bookRepository.saveAll(books);
        }

        // Authentication
        public User authenticate(String id, String password) {
                if (id == null || password == null)
                        return null;
                Optional<User> uObj = userRepository.findById(id);
                if (uObj.isPresent()) {
                        User u = uObj.get();
                        if (password.equals(u.getPassword())) {
                                return u;
                        }
                }
                return null;
        }

        // Sign-up (Public)
        @Transactional
        public synchronized String signUp(String name, String surname, String password) {
                return createMember(name, surname, password, null);
        }

        // Create Member (Internal/Admin)
        @Transactional
        public synchronized String createMember(String name, String surname, String password, String avatarUrl) {
                if (name == null || name.trim().isEmpty() ||
                                surname == null || surname.trim().isEmpty() ||
                                password == null || password.trim().isEmpty()) {
                        throw new IllegalArgumentException("Ad, Soyad və Şifrə boş ola bilməz.");
                }
                String id = generateMemberId();
                Member m = new Member(id, name, surname, password);
                if (avatarUrl != null)
                        m.setAvatarUrl(avatarUrl);
                userRepository.save(m);
                return id;
        }

        @Transactional
        @SuppressWarnings("null")
        public User updateUserProfile(String id, String name, String surname, String password, String avatarUrl) {
                Optional<User> uOpt = userRepository.findById(id);
                if (uOpt.isEmpty()) {
                        throw new IllegalArgumentException("İstifadəçi tapılmadı.");
                }
                User u = uOpt.get();
                if (name != null && !name.trim().isEmpty())
                        u.setName(name);
                if (surname != null && !surname.trim().isEmpty())
                        u.setSurname(surname);
                if (password != null && !password.trim().isEmpty())
                        u.setPassword(password);
                if (avatarUrl != null) // Allow empty string to clear? For now just update if present
                        u.setAvatarUrl(avatarUrl);

                return userRepository.save(u);
        }

        @Transactional // Preserving old signature for compatibility/refactoring ease
        public User updateUserProfile(String id, String name, String surname, String password) {
                return updateUserProfile(id, name, surname, password, null);
        }

        // Book APIs
        public List<Book> getAllBooks() {
                return bookRepository.findAll();
        }

        @Transactional
        public synchronized String addBook(String isbn, String title, String author, String genre, int year) {
                // If book exists, increment stock? Or allow duplicates?
                // Plan says simple add. But usually same ISBN = same book.
                // For this project, let's just create new entry or error if ISBN conflict logic
                // is strict.
                // Reverting to implementation plan: "Add stock field". logic below uses new
                // constructor.
                if (bookRepository.findByIsbn(isbn).isPresent()) {
                        // Start: Update stock instead of error?
                        // For now, adhere to existing logic but maybe allow duplicates if demanded.
                        // User request #3 "Library books stock system".
                        // Let's just create it with stock 50.
                        return "Xəta: Bu ISBN-li kitab artıq mövcuddur.";
                }
                Book b = new Book(generateBookId(), isbn, title, author, genre, year, 50); // Default 50 stock
                bookRepository.save(b);
                return b.getId();
        }

        // ... getters ...

        // Loaning
        @Transactional
        @SuppressWarnings("null")
        public synchronized String borrowBook(String bookId, String memberId) {
                Optional<Book> bOpt = bookRepository.findById(bookId);
                Optional<User> uOpt = userRepository.findById(memberId);

                if (bOpt.isEmpty() || uOpt.isEmpty() || !(uOpt.get() instanceof Member)) {
                        return "Xəta: Kitab və ya oxucu tapılmadı.";
                }

                Book b = bOpt.get();
                Member m = (Member) uOpt.get();

                if (!b.isAvailable())
                        return "Xəta: Kitabın stok sayı bitib.";

                // Check if user already has this book actively borrowed
                boolean alreadyBorrowed = loanRepository.findByReturnDateIsNull().stream()
                                .anyMatch(l -> l.getBook().getId().equals(bookId)
                                                && l.getMember().getId().equals(memberId));

                if (alreadyBorrowed) {
                        return "Xəta: Siz bu kitabı artıq götürmüsünüz.";
                }

                try {
                        b.markAsBorrowed(); // Use stock logic
                        Loan loan = new Loan(generateLoanId(), b, m);
                        loanRepository.save(loan);
                        bookRepository.save(b); // Update stock
                        return loan.getLoanId();
                } catch (IllegalStateException e) {
                        return "Xəta: " + e.getMessage();
                }
        }

        @Transactional
        public synchronized String returnBook(String bookId, String memberId) {
                // Find active loan for this book and member
                List<Loan> activeLoans = loanRepository.findByReturnDateIsNull();
                Optional<Loan> active = activeLoans.stream()
                                .filter(l -> l.getBook().getId().equals(bookId)
                                                && l.getMember().getId().equals(memberId))
                                .findFirst();

                if (active.isEmpty())
                        return "Xəta: Bu oxucuda həmin kitaba dair aktiv borc tapılmadı.";

                Loan loan = active.get();
                loan.markAsReturned();

                Book b = loan.getBook();
                if (b != null) {
                        b.markAsReturned(); // Use stock logic
                        bookRepository.save(b);
                }

                // ... rest is same
                Member m = loan.getMember();
                if (m != null) {
                        m.increaseReadCount();
                        userRepository.save(m);
                }

                loanRepository.save(loan);
                return loan.isOverdue() ? "GECİKMƏDƏ" : "UĞURLA QAYTARILDI";
        }

        public List<Loan> getOverdueLoans() {
                return loanRepository.findAll().stream().filter(Loan::isOverdue).collect(Collectors.toList());
        }

        public List<Loan> getActiveLoans() {
                return loanRepository.findByReturnDateIsNull();
        }

        @Transactional
        @SuppressWarnings("null")
        public synchronized void deleteUser(String id) {
                // Check if user has active loans
                boolean hasActiveLoans = loanRepository.findByReturnDateIsNull().stream()
                                .anyMatch(l -> l.getMember().getId().equals(id));

                if (hasActiveLoans) {
                        throw new IllegalArgumentException("İstifadəçinin aktiv borcları var, silinə bilməz.");
                }

                if (!userRepository.existsById(id)) {
                        throw new IllegalArgumentException("İstifadəçi tapılmadı.");
                }

                userRepository.deleteById(id);
        }

        public List<Member> getAllMembers() {
                return userRepository.findAll().stream()
                                .filter(u -> u instanceof Member)
                                .map(u -> (Member) u)
                                .collect(Collectors.toList());
        }

        @Transactional
        @SuppressWarnings("null")
        public Book updateBook(String id, String isbn, String title, String author, String genre, int year) {
                Optional<Book> bOpt = bookRepository.findById(id);
                if (bOpt.isEmpty()) {
                        throw new IllegalArgumentException("Kitab tapılmadı.");
                }
                Book b = bOpt.get();
                b.setIsbn(isbn);
                b.setTitle(title);
                b.setAuthor(author);
                b.setGenre(genre);
                b.setYear(year);
                // Stock is not updated here currently, separate logic or add if needed
                return bookRepository.save(b);
        }

        // Helpers
        @SuppressWarnings("null")
        public Optional<Book> findBookById(String id) {
                return bookRepository.findById(id);
        }

        @SuppressWarnings("null")
        public Optional<User> findUserById(String id) {
                return userRepository.findById(id);
        }

        @Transactional
        @SuppressWarnings("null")
        public void deleteBook(String id) {
                Optional<Book> bOpt = bookRepository.findById(id);
                if (bOpt.isEmpty()) {
                        throw new IllegalArgumentException("Kitab tapılmadı.");
                }

                // Check for active loans
                boolean hasActiveLoans = loanRepository.findByReturnDateIsNull().stream()
                                .anyMatch(l -> l.getBook().getId().equals(id));

                if (hasActiveLoans) {
                        throw new IllegalArgumentException("Bu kitab hazırda oxucudadır (aktiv borc), silinə bilməz.");
                }

                loanRepository.findAll().stream()
                                .filter(l -> l.getBook().getId().equals(id))
                                .forEach(l -> loanRepository.delete(l));

                bookRepository.deleteById(id);
        }
}