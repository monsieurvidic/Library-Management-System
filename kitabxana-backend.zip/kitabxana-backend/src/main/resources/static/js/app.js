const App = {
    user: null,
    books: [],
    allBooks: [], // Keep original full list
    loans: [],
    members: [],
    overdue: [],
    isDarkMode: false,
    currentSearchQuery: '',
    currentGenreFilter: 'all',
    container: document.getElementById('app'),

    async init() {
        // Theme Check
        const savedTheme = localStorage.getItem('readify_theme');
        if (savedTheme === 'dark') {
            this.isDarkMode = true;
            document.documentElement.setAttribute('data-theme', 'dark');
        }

        // User Check
        const savedUser = localStorage.getItem('readify_user');
        if (savedUser) {
            this.user = JSON.parse(savedUser);
            this.loadDashboardData();
        } else {
            this.showLogin();
        }
    },

    updateView(html) {
        this.container.innerHTML = html;
    },

    toggleTheme() {
        this.isDarkMode = !this.isDarkMode;
        if (this.isDarkMode) {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('readify_theme', 'dark');
        } else {
            document.documentElement.removeAttribute('data-theme');
            localStorage.setItem('readify_theme', 'light');
        }
        // Re-render to update icon
        if (this.user) {
            this.showDashboard();
        } else {
            // If not logged in, just update the view
            this.showLogin();
        }
    },

    showToast(msg, type = 'info') {
        const t = document.getElementById('toast');
        if (t) {
            t.innerText = msg;
            t.className = 'toast show';
            if (type === 'error') {
                t.style.background = 'var(--danger)';
            } else if (type === 'success') {
                t.style.background = 'var(--success)';
            } else {
                t.style.background = 'var(--primary)';
            }
            setTimeout(() => {
                t.classList.remove('show');
                t.style.background = '';
            }, 3000);
        }
    },

    // --- Auth ---
    showLogin() {
        this.updateView(Components.renderLogin());
    },

    showRegister() {
        this.updateView(Components.renderRegister());
    },

    async handleLogin(e) {
        e.preventDefault();
        const id = document.getElementById('loginId').value;
        const pass = document.getElementById('loginPass').value;
        try {
            const user = await API.login(id, pass);
            this.setUser(user);
        } catch (err) {
            alert('Giriş xətası: ' + err.message);
        }
    },

    async handleRegister(e) {
        e.preventDefault();
        const name = document.getElementById('regName').value;
        const surname = document.getElementById('regSurname').value;
        const pass = document.getElementById('regPass').value;
        try {
            const res = await API.signUp(name, surname, pass);
            alert(`Uğurlu! Sizin ID: ${res.memberId}. Zəhmət olmasa daxil olun.`);
            this.showLogin();
        } catch (err) {
            alert(err.message);
        }
    },

    setUser(user) {
        this.user = user;
        localStorage.setItem('readify_user', JSON.stringify(user));
        this.loadDashboardData();
    },

    logout() {
        this.user = null;
        this.books = [];
        this.allBooks = [];
        localStorage.removeItem('readify_user');
        this.showLogin();
    },

    // --- Dashboard Data Loading ---
    async loadDashboardData() {
        if (!this.user) return;

        try {
            const isAdmin = (this.user.role === 'LIBRARIAN');
            const promises = [
                API.getBooks(),
                API.getActiveLoans(),
                API.getOverdueLoans()
            ];

            if (isAdmin) {
                promises.push(API.getMembers());
            }

            const results = await Promise.all(promises);
            const books = results[0];
            const activeLoans = results[1];
            const overdueLoans = results[2];
            const members = isAdmin ? results[3] : [];

            this.allBooks = books; // Store full list
            this.books = books; // Display list
            this.loans = activeLoans;
            this.overdue = overdueLoans || [];
            this.members = members || []; // Store members

            this.showDashboard();
        } catch (err) {
            console.error('Dashboard Load Error:', err);
            alert('Məlumatları yükləmək mümkün olmadı: ' + err.message);
            this.showDashboard();
        }
    },

    showDashboard() {
        if (!this.user) return;

        const isAdmin = (this.user.role === 'LIBRARIAN');

        const stats = {
            totalBooks: this.allBooks.length,
            activeLoans: this.loans.length,
            overdue: this.overdue ? this.overdue.length : 0
        };

        let content = '';

        if (isAdmin) {
            content = Components.renderStats(stats) + Components.renderActiveLoansTable(this.loans) + Components.renderAdminPanel(this.books, this.members);
        } else {
            // Extract unique genres
            const genres = [...new Set(this.allBooks.map(b => b.genre))].sort();
            content = Components.renderHero(genres) + Components.renderBookGrid(this.books, this.user.role, this.user.id, this.loans);
        }

        this.updateView(Components.renderDashboard(this.user, content));
    },

    // Used to refresh just the content part without full reload if possible, but for now simple alias to showDashboard
    refreshDashboardState() {
        this.showDashboard();
    },

    // --- Filtering Logic ---
    handleSearch(query) {
        this.currentSearchQuery = query.toLowerCase();
        this.applyFilters();
    },

    handleGenreFilter(genre) {
        this.currentGenreFilter = genre;
        this.applyFilters();
    },

    applyFilters() {
        let filtered = this.allBooks;

        // 1. Text Search
        if (this.currentSearchQuery) {
            filtered = filtered.filter(b =>
                b.title.toLowerCase().includes(this.currentSearchQuery) ||
                b.author.toLowerCase().includes(this.currentSearchQuery) ||
                (b.isbn && b.isbn.includes(this.currentSearchQuery))
            );
        }

        // 2. Genre Filter
        if (this.currentGenreFilter !== 'all') {
            filtered = filtered.filter(b => b.genre === this.currentGenreFilter);
        }

        this.books = filtered;
        this.refreshBookDisplay();
    },

    // --- Modal Helpers ---
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) modal.remove();
    },

    // --- Book Management ---
    showAddBookModal() {
        // Reuse Edit Modal logic but empty
        const emptyBook = { id: '', title: '', author: '', isbn: '', genre: '', year: '' };
        // We'll use a slightly different render or just clear values? 
        // For simplicity, let's assume we renderEditBookModal but handle save as create if ID is empty.
        // Actually, let's create a dedicated renderAddBookModal or reuse.
        // To save time, we'll create the modal manually or add a render method if needed.
        // Let's use the existing renderEditBookModal but with empty data, and handle logic in handleBookUpdate
        const modalHtml = Components.renderEditBookModal(emptyBook);
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        // Fix title
        document.querySelector('#editBookModal h2').innerText = 'Yeni Kitab';
    },

    showEditBookModal(id) {
        const book = this.allBooks.find(b => b.id === id);
        if (book) {
            const modalHtml = Components.renderEditBookModal(book);
            document.body.insertAdjacentHTML('beforeend', modalHtml);
        }
    },

    async handleBookUpdate(e) {
        e.preventDefault();
        const id = document.getElementById('ebId').value; // Empty if new
        const isbn = document.getElementById('ebIsbn').value;
        const title = document.getElementById('ebTitle').value;
        const author = document.getElementById('ebAuthor').value;
        const genre = document.getElementById('ebGenre').value;
        const year = document.getElementById('ebYear').value;

        try {
            if (id) {
                // Update - API expects a book object
                await API.updateBook({ id, isbn, title, author, genre, year: parseInt(year) });
                this.showToast('Kitab yeniləndi', 'success');
            } else {
                // Create - API expects a book object
                await API.addBook({ isbn, title, author, genre, year: parseInt(year) });
                this.showToast('Kitab əlavə edildi', 'success');
            }
            this.closeModal('editBookModal');
            await this.loadDashboardData();
        } catch (err) {
            this.showToast(err.message, 'error');
        }
    },

    // --- User Management ---
    showEditUserModal(id) {
        const user = this.members.find(u => u.id === id);
        if (user) {
            const modalHtml = Components.renderEditUserModal(user);
            document.body.insertAdjacentHTML('beforeend', modalHtml);
        }
    },

    refreshBookDisplay() {
        const wrapper = document.getElementById('books-wrapper');
        if (wrapper) {
            const newContent = Components.renderBookGrid(this.books, this.user.role, this.user.id, this.loans);
            wrapper.outerHTML = newContent;
        }
    },

    // --- Actions ---
    async borrowBook(bookId) {
        if (!confirm('Bu kitabı götürmək istəyirsiniz?')) return;
        try {
            await API.borrowBook(bookId, this.user.id);
            this.showToast('Kitab uğurla icarəyə götürüldü!', 'success');
            await this.loadDashboardData();
        } catch (err) {
            this.showToast(err.message, 'error');
        }
    },

    async returnBook(bookId) {
        if (!confirm('Kitabı qaytarmaq istəyirsiniz?')) return;
        try {
            const res = await API.returnBook(bookId, this.user.id);
            this.showToast(res.status || 'Kitab qaytarıldı', 'success');
            await this.loadDashboardData();
        } catch (err) {
            this.showToast(err.message, 'error');
        }
    },

    // --- Profile Modal ---
    showProfileModal() {
        const modalHtml = Components.renderProfileModal(this.user);
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    },

    closeProfileModal() {
        const modal = document.getElementById('profileModal');
        if (modal) modal.remove();
    },

    async handleProfileUpdate(e) {
        e.preventDefault();
        const av = document.getElementById('pAvatar').value;
        const name = document.getElementById('pName').value;
        const surname = document.getElementById('pSurname').value;
        const pass = document.getElementById('pPass').value;

        try {
            const updatedUser = await API.updateProfile(this.user.id, name, surname, pass, av);
            this.setUser(updatedUser);
            this.showToast('Profil uğurla yeniləndi', 'success');
            this.closeProfileModal();
        } catch (err) {
            this.showToast(err.message, 'error');
        }
    },

    // --- Member Mgmt ---
    showAddMemberModal() {
        const modalHtml = Components.renderAddMemberModal();
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    },

    async handleAddMember(e) {
        e.preventDefault();
        const name = document.getElementById('amName').value;
        const surname = document.getElementById('amSurname').value;
        const pass = document.getElementById('amPass').value;

        try {
            await API.addMember(name, surname, pass);
            this.closeModal('addMemberModal');
            this.showToast('İstifadəçi əlavə edildi', 'success');
            await this.loadDashboardData(); // Refresh admin list
        } catch (err) {
            this.showToast(err.message, 'error');
        }
    },

    // ... (Book Modals same) ...

    async handleUserUpdate(e) {
        e.preventDefault();
        const id = document.getElementById('euId').value;
        const name = document.getElementById('euName').value;
        const surname = document.getElementById('euSurname').value;
        const password = document.getElementById('euPass').value;
        const avatarUrl = document.getElementById('euAvatar').value;

        try {
            await API.updateUser(id, name, surname, password, avatarUrl);
            this.closeModal('editUserModal');
            this.showToast('İstifadəçi uğurla yeniləndi', 'success');
            await this.loadDashboardData();
        } catch (err) {
            this.showToast(err.message, 'error');
        }
    },

    async deleteUser(id) {
        if (!confirm('Bu istifadəçini silmək istədiyinizə əminsiniz?')) return;

        try {
            await API.deleteUser(id);
            this.showToast('İstifadəçi silindi', 'success');
            // Remove from local state immediately for better UX
            this.members = this.members.filter(m => m.id !== id);
            this.refreshDashboardState();
        } catch (err) {
            this.showToast('Xəta: ' + err.message, 'error');
        }
    },

    async deleteBook(id) {

        if (!confirm('Bu kitabı silmək istədiyinizə əminsiniz? Diqqət: Geri qaytarmaq mümkün deyil.')) {

            return;
        }

        try {
            const result = await API.deleteBook(id);
            this.showToast('Kitab silindi', 'success');
            this.books = this.books.filter(b => b.id !== id);
            this.allBooks = this.allBooks.filter(b => b.id !== id);
            await this.loadDashboardData(); // Reload to ensure consistency
        } catch (err) {
            console.error('Delete book error:', err);
            this.showToast('Xəta: ' + err.message, 'error');
        }
    }
};

document.addEventListener('DOMContentLoaded', () => {
    // Immediate Theme Check
    const savedTheme = localStorage.getItem('readify_theme');
    if (savedTheme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
        App.isDarkMode = true;
    }
    App.init();

    // Event Delegation for dynamically created buttons with data-action attributes
    document.addEventListener('click', (e) => {
        const target = e.target.closest('[data-action]');
        if (!target) return;

        const action = target.getAttribute('data-action');
        const bookId = target.getAttribute('data-book-id');
        const userId = target.getAttribute('data-user-id');

        switch (action) {
            case 'delete-book':
                if (bookId) App.deleteBook(bookId);
                break;
            case 'delete-user':
                if (userId) App.deleteUser(userId);
                break;
            case 'return-book':
                if (bookId) App.returnBook(bookId);
                break;
            case 'borrow-book':
                if (bookId) App.borrowBook(bookId);
                break;
        }
    });
});
window.App = App;
