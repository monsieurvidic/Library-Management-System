const Components = {
    // Navbar Component
    renderNavbar(user, isDark) {
        const themeIcon = isDark ? 'fa-sun' : 'fa-moon';
        const avatarContent = user.avatarUrl
            ? `<img src="${user.avatarUrl}" style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover;">`
            : `<div style="width: 32px; height: 32px; background: var(--primary); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.8rem;">${user.name.charAt(0)}</div>`;

        const userContent = user
            ? `
                <div style="display: flex; align-items: center; gap: 1rem;">
                    <button onclick="App.showProfileModal()" class="btn-text" style="display: flex; align-items: center; gap: 0.5rem; text-decoration: none; color: var(--text-main); font-weight: 500; background: none; border: none; cursor: pointer;">
                        <span style="font-size: 0.9rem;">${user.name}</span>
                        ${avatarContent}
                    </button>
                    <button onclick="App.logout()" class="btn btn-secondary btn-sm" title="Çıxış"><i class="fas fa-sign-out-alt"></i></button>
                </div>
            `
            : `<button onclick="App.showLogin()" class="btn btn-primary btn-sm">Daxil Ol</button>`;

        // ... (rest same)
        return `
            <nav class="navbar">
                <a href="#" onclick="App.showDashboard()" class="logo">
                    <i class="fas fa-book-reader"></i> Readify
                </a>
                <div class="nav-right">
                    <button onclick="App.toggleTheme()" class="theme-toggle">
                        <i class="fas ${themeIcon}"></i>
                    </button>
                    ${userContent}
                </div>
            </nav>
        `;
    },

    // ... (Auth/Hero/Stats same) ...

    // Book Grid - Update for Return Button
    renderBookGrid(books, userRole, currentUserId, activeLoans) {
        if (!books || books.length === 0) {
            return `<div style="text-align: center; color: var(--text-muted); padding: 3rem;">Axtarışa uyğun kitab tapılmadı.</div>`;
        }

        // Find borrowed books by this user
        const myLoanedBookIds = activeLoans
            ? activeLoans.filter(l => l.member && l.member.id === currentUserId).map(l => l.book ? l.book.id : null)
            : [];

        const cards = books.map(book => {
            const isAvailable = book.available;
            const stock = book.stock !== undefined ? book.stock : 1;
            const statusClass = isAvailable ? 'status-available' : 'status-borrowed';
            const statusText = isAvailable ? `Mövcuddur (Say: ${stock})` : 'Bitib';
            const showAction = userRole !== 'LIBRARIAN';

            const isBorrowedByMe = myLoanedBookIds.includes(book.id);

            let actionButton = '';
            if (showAction) {
                if (isBorrowedByMe) {
                    actionButton = `<button data-action="return-book" data-book-id="${book.id}" class="btn btn-secondary btn-sm" style="background: var(--warning); color:white; border:none;">Qaytar</button>`;
                } else if (isAvailable) {
                    actionButton = `<button data-action="borrow-book" data-book-id="${book.id}" class="btn btn-primary btn-sm">Götür</button>`;
                }
            }

            return `
                <div class="book-card">
                    <div class="book-cover">
                        ${book.imageUrl
                    ? `<img src="${book.imageUrl}" alt="${book.title}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
                               <i class="fas fa-book" style="display:none; font-size: 2rem;"></i>`
                    : `<i class="fas fa-book"></i>`}
                    </div>
                    <div class="book-content">
                        <h3 class="book-title" title="${book.title}">${book.title}</h3>
                        <p class="book-author">${book.author}</p>
                        <div class="book-tags">
                            <span class="book-status ${statusClass}">${statusText}</span>
                            ${actionButton}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        return `
            <div id="books-wrapper">
                <h2 class="section-title">Kitabxana Fondu</h2>
                <div class="books-grid">
                    ${cards}
                </div>
            </div>
        `;
    },

    // Admin Table - Update for Avatar
    renderAdminPanel(books, users) {
        return `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2 class="section-title" style="margin-bottom: 0;">İdarəetmə Paneli</h2>
                <div>
                     <button onclick="App.showAddMemberModal()" class="btn btn-secondary" style="margin-right:0.5rem;"><i class="fas fa-user-plus"></i> Yeni İstifadəçi</button>
                     <button onclick="App.showAddBookModal()" class="btn btn-primary"><i class="fas fa-plus"></i> Yeni Kitab</button>
                </div>
            </div>

            <!-- Books Table (Same) -->
            <div style="background: var(--bg-card); border-radius: var(--radius-lg); border: 1px solid var(--border); overflow: hidden; margin-bottom: 2rem;">
                <div style="padding: 1rem; border-bottom: 1px solid var(--border); background: rgba(0,0,0,0.02); font-weight: 600;">Kitablar</div>
                <table class="data-table" style="margin-top: 0; border: none; border-radius: 0;">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Kitab</th>
                            <th>Müəllif</th>
                            <th>Stok</th>
                            <th>Əməliyyat</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${books.map(b => `
                            <tr>
                                <td><span style="font-family: monospace; color: var(--text-muted);">${b.id}</span></td>
                                <td><strong>${b.title}</strong></td>
                                <td>${b.author}</td>
                                <td>${b.stock}</td>
                                <td>
                                    <button onclick="App.showEditBookModal('${b.id}')" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.5rem;"><i class="fas fa-edit"></i></button>
                                    <button data-action="delete-book" data-book-id="${b.id}" class="btn btn-secondary btn-sm" style="color: var(--danger); border-color: var(--danger); padding: 0.25rem 0.5rem; margin-left: 0.5rem;"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>

            <!-- Users Table -->
            <div style="background: var(--bg-card); border-radius: var(--radius-lg); border: 1px solid var(--border); overflow: hidden;">
                <div style="padding: 1rem; border-bottom: 1px solid var(--border); background: rgba(0,0,0,0.02); font-weight: 600;">İstifadəçilər</div>
                <table class="data-table" style="margin-top: 0; border: none; border-radius: 0;">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Profil</th>
                            <th>Ad Soyad</th>
                            <th>Rol</th>
                            <th>Əməliyyat</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${users.map(u => {
            const avatar = u.avatarUrl
                ? `<img src="${u.avatarUrl}" style="width: 24px; height: 24px; border-radius: 50%; vertical-align: middle;">`
                : `<span style="width: 24px; height: 24px; background: #ccc; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 0.7rem; color: #fff;">${u.name.charAt(0)}</span>`;

            return `
                            <tr>
                                <td><span style="font-family: monospace; color: var(--text-muted);">${u.id}</span></td>
                                <td>${avatar}</td>
                                <td>${u.name} ${u.surname}</td>
                                <td>${u.role}</td>
                                <td>
                                    ${u.role !== 'LIBRARIAN' ? `
                                        <button onclick="App.showEditUserModal('${u.id}')" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.5rem; margin-right: 0.5rem;"><i class="fas fa-edit"></i></button>
                                        <button data-action="delete-user" data-user-id="${u.id}" class="btn btn-secondary btn-sm" style="color: var(--danger); border-color: var(--danger); padding: 0.25rem 0.5rem;"><i class="fas fa-trash"></i> Sil</button>
                                    ` : ''}
                                </td>
                            </tr>
                        `;
        }).join('')}
                    </tbody>
                </table>
            </div>
        `;
    },

    // Active Loans Table for Librarian
    renderActiveLoansTable(loans) {
        if (!loans || loans.length === 0) {
            return `
                <div style="background: var(--bg-card); border-radius: var(--radius-lg); border: 1px solid var(--border); overflow: hidden; margin-bottom: 2rem;">
                    <div style="padding: 1rem; border-bottom: 1px solid var(--border); background: rgba(0,0,0,0.02); font-weight: 600;">
                        <i class="fas fa-hand-holding"></i> Aktiv İcarələr
                    </div>
                    <div style="padding: 2rem; text-align: center; color: var(--text-muted);">
                        Hal-hazırda aktiv icarə yoxdur
                    </div>
                </div>
            `;
        }

        return `
            <div style="background: var(--bg-card); border-radius: var(--radius-lg); border: 1px solid var(--border); overflow: hidden; margin-bottom: 2rem;">
                <div style="padding: 1rem; border-bottom: 1px solid var(--border); background: rgba(0,0,0,0.02); font-weight: 600;">
                    <i class="fas fa-hand-holding"></i> Aktiv İcarələr (${loans.length})
                </div>
                <table class="data-table" style="margin-top: 0; border: none; border-radius: 0;">
                    <thead>
                        <tr>
                            <th>Üzv</th>
                            <th>Kitab</th>
                            <th>Götürülmə Tarixi</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${loans.map(loan => {
            const memberName = loan.member ? `${loan.member.name} ${loan.member.surname}` : 'Naməlum';
            const memberId = loan.member ? loan.member.id : '-';
            const bookTitle = loan.book ? loan.book.title : 'Naməlum';
            const bookAuthor = loan.book ? loan.book.author : '';
            const borrowDate = loan.borrowedAt ? new Date(loan.borrowedAt).toLocaleDateString('az-AZ') : '-';

            // Check if overdue (simple check)
            const isOverdue = loan.overdue || false;
            const statusClass = isOverdue ? 'status-borrowed' : 'status-available';
            const statusText = isOverdue ? 'Gecikmiş' : 'Aktiv';

            return `
                                <tr>
                                    <td>
                                        <div>
                                            <strong>${memberName}</strong>
                                            <div style="font-size: 0.85rem; color: var(--text-muted); font-family: monospace;">${memberId}</div>
                                        </div>
                                    </td>
                                    <td>
                                        <div>
                                            <strong>${bookTitle}</strong>
                                            ${bookAuthor ? `<div style="font-size: 0.85rem; color: var(--text-muted);">${bookAuthor}</div>` : ''}
                                        </div>
                                    </td>
                                    <td>${borrowDate}</td>
                                    <td><span class="book-status ${statusClass}">${statusText}</span></td>
                                </tr>
                            `;
        }).join('')}
                    </tbody>
                </table>
            </div>
        `;
    },

    // ... (Empty State) ...

    renderProfileModal(user) {
        return `
            <div class="modal-overlay" id="profileModal">
                <div class="modal-card">
                    <div class="modal-header">
                        <h2>Profil Ayarları</h2>
                        <button onclick="App.closeModal('profileModal')" class="btn-icon"><i class="fas fa-times"></i></button>
                    </div>
                    <form onsubmit="App.handleProfileUpdate(event)">
                        <div class="form-group">
                            <label class="form-label">Avatar URL</label>
                            <input type="text" id="pAvatar" class="form-input" value="${user.avatarUrl || ''}" placeholder="https://...">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Ad</label>
                            <input type="text" id="pName" class="form-input" value="${user.name}" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Soyad</label>
                            <input type="text" id="pSurname" class="form-input" value="${user.surname}" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Yeni Şifrə (Dəyişmək istəmirsinizsə boş buraxın)</label>
                            <input type="password" id="pPass" class="form-input" placeholder="••••••">
                        </div>
                        <div class="form-actions">
                            <button type="button" onclick="App.closeModal('profileModal')" class="btn btn-secondary">Ləğv et</button>
                            <button type="submit" class="btn btn-primary">Yadda Saxla</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    },

    renderAddMemberModal() {
        return `
            <div class="modal-overlay" id="addMemberModal">
                <div class="modal-card">
                    <div class="modal-header">
                        <h2>Yeni İstifadəçi</h2>
                        <button onclick="App.closeModal('addMemberModal')" class="btn-icon"><i class="fas fa-times"></i></button>
                    </div>
                    <form onsubmit="App.handleAddMember(event)">
                        <div class="form-group">
                            <label class="form-label">Ad</label>
                            <input type="text" id="amName" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Soyad</label>
                            <input type="text" id="amSurname" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Şifrə</label>
                            <input type="password" id="amPass" class="form-input" required>
                        </div>
                        <div class="form-actions">
                            <button type="button" onclick="App.closeModal('addMemberModal')" class="btn btn-secondary">Ləğv et</button>
                            <button type="submit" class="btn btn-primary">Əlavə Et</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    },



    // Auth Components
    renderLogin() {
        return `
            <div class="auth-container">
                <div class="auth-card">
                    <div class="auth-header">
                        <h1>Xoş Gəlmisiniz</h1>
                        <p>Hesabınıza daxil olun</p>
                    </div>
                    <form onsubmit="App.handleLogin(event)">
                        <div class="form-group">
                            <label class="form-label">İstifadəçi ID</label>
                            <input type="text" id="loginId" class="form-input" placeholder="Mxxxxxx" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Şifrə</label>
                            <input type="password" id="loginPass" class="form-input" placeholder="••••••" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Daxil Ol</button>
                        <div style="margin-top: 1.5rem; font-size: 0.9rem; color: var(--text-muted);">
                            Hesabınız yoxdur? <a href="#" onclick="App.showRegister()" style="color: var(--primary); text-decoration: none; font-weight: 500;">Qeydiyyatdan Keç</a>
                        </div>
                    </form>
                </div>
            </div>
        `;
    },

    renderRegister() {
        return `
            <div class="auth-container">
                <div class="auth-card">
                    <div class="auth-header">
                        <h1>Qeydiyyat</h1>
                        <p>Readify ailəsinə qoşulun</p>
                    </div>
                    <form onsubmit="App.handleRegister(event)">
                        <div class="form-group">
                            <label class="form-label">Ad</label>
                            <input type="text" id="regName" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Soyad</label>
                            <input type="text" id="regSurname" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Şifrə</label>
                            <input type="password" id="regPass" class="form-input" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Qeydiyyatı Tamamla</button>
                        <div style="margin-top: 1.5rem; font-size: 0.9rem; color: var(--text-muted);">
                            Artıq hesabınız var? <a href="#" onclick="App.showLogin()" style="color: var(--primary); text-decoration: none; font-weight: 500;">Daxil Ol</a>
                        </div>
                    </form>
                </div>
            </div>
        `;
    },

    // Dashboard Structure
    renderDashboard(user, content) {
        return `
            ${this.renderNavbar(user, App.isDarkMode)}
            <main class="dashboard-container">
                ${content}
                <div style="text-align: center; color: var(--text-muted); padding: 2rem; font-size: 0.8rem; opacity: 0.7;">
                    Readify System v2.1 • <span style="color: var(--success)">● Sistemi Onlayn</span>
                </div>
            </main>
        `;
    },

    // Hero Search Section
    renderHero(genres = []) {
        const genreOptions = genres.map(g => `<option value="${g}">${g}</option>`).join('');

        return `
            <section class="hero-section">
                <h1 class="hero-title">Nə oxumaq istəyirsiniz?</h1>
                <div class="search-box">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" id="searchInput" class="search-input" placeholder="Kitab adı, müəllif və ya ISBN axtar..." oninput="App.handleSearch(this.value)">
                </div>
                <div style="max-width: 600px; margin: 1.5rem auto; display: flex; gap: 1rem; align-items: center;">
                    <label style="font-weight: 500; color: var(--text-main);">Janr:</label>
                    <select id="genreFilter" onchange="App.handleGenreFilter(this.value)" style="flex: 1; padding: 0.75rem; border: 2px solid var(--border); border-radius: var(--radius-md); background: var(--bg-card); color: var(--text-main); font-family: inherit;">
                        <option value="all">Hamısı</option>
                        ${genreOptions}
                    </select>
                </div>
            </section>
        `;
    },

    // Statistics Cards
    renderStats(stats) {
        return `
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon blue"><i class="fas fa-book-open"></i></div>
                    <div class="stat-info">
                        <h3>${stats.totalBooks || 0}</h3>
                        <p>Ümumi Kitab</p>
                    </div>
                </div>
                <div class="stat-card orange">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-info">
                        <h3>${stats.overdue || 0}</h3>
                        <p>Gecikmədə olan</p>
                    </div>
                </div>
                <div class="stat-card cyan">
                    <div class="stat-icon"><i class="fas fa-hand-holding"></i></div>
                    <div class="stat-info">
                        <h3>${stats.activeLoans || 0}</h3>
                        <p>Aktiv Borclar</p>
                    </div>
                </div>
            </div>
        `;
    },

    renderEmptyState(message) {
        return `<div style="text-align: center; color: var(--text-muted); padding: 5rem;">${message}</div>`;
    },

    renderEditBookModal(book) {
        return `
            <div class="modal-overlay" id="editBookModal">
                <div class="modal-card">
                    <div class="modal-header">
                        <h2>Kitabı Redaktə Et</h2>
                        <button onclick="App.closeModal('editBookModal')" class="btn-icon"><i class="fas fa-times"></i></button>
                    </div>
                    <form onsubmit="App.handleBookUpdate(event)">
                        <input type="hidden" id="ebId" value="${book.id}">
                        <div class="form-group">
                            <label class="form-label">ISBN</label>
                            <input type="text" id="ebIsbn" class="form-input" value="${book.isbn || ''}" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Ad</label>
                            <input type="text" id="ebTitle" class="form-input" value="${book.title}" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Müəllif</label>
                            <input type="text" id="ebAuthor" class="form-input" value="${book.author}" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Janr</label>
                            <input type="text" id="ebGenre" class="form-input" value="${book.genre}" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">İl</label>
                            <input type="number" id="ebYear" class="form-input" value="${book.year || ''}" required>
                        </div>
                        <div class="form-actions">
                            <button type="button" onclick="App.closeModal('editBookModal')" class="btn btn-secondary">Ləğv et</button>
                            <button type="submit" class="btn btn-primary">Yadda Saxla</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    },

    renderEditUserModal(user) {
        return `
            <div class="modal-overlay" id="editUserModal">
                <div class="modal-card">
                    <div class="modal-header">
                        <h2>İstifadəçini Redaktə Et</h2>
                        <button onclick="App.closeModal('editUserModal')" class="btn-icon"><i class="fas fa-times"></i></button>
                    </div>
                    <form onsubmit="App.handleUserUpdate(event)">
                        <input type="hidden" id="euId" value="${user.id}">
                        <div class="form-group">
                            <label class="form-label">Ad</label>
                            <input type="text" id="euName" class="form-input" value="${user.name}" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Soyad</label>
                            <input type="text" id="euSurname" class="form-input" value="${user.surname}" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Avatar URL</label>
                            <input type="text" id="euAvatar" class="form-input" value="${user.avatarUrl || ''}" placeholder="https://...">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Yeni Şifrə (Boş buraxıla bilər)</label>
                            <input type="password" id="euPass" class="form-input" placeholder="••••••">
                        </div>
                        <div class="form-actions">
                            <button type="button" onclick="App.closeModal('editUserModal')" class="btn btn-secondary">Ləğv et</button>
                            <button type="submit" class="btn btn-primary">Yadda Saxla</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    }
};
