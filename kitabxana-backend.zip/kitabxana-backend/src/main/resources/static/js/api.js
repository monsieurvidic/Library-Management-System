const API = {
    baseUrl: '/api',

    async login(id, password) {
        const res = await fetch(`${this.baseUrl}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, password })
        });
        if (!res.ok) throw new Error(await res.text());
        return await res.json();
    },

    async signUp(name, surname, password) {
        const res = await fetch(`${this.baseUrl}/auth/signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, surname, password })
        });
        if (!res.ok) throw new Error(await res.text());
        return await res.json();
    },

    async getBooks() {
        const res = await fetch(`${this.baseUrl}/books`, { cache: 'no-store' });
        return await res.json();
    },

    async addBook(book) {
        const res = await fetch(`${this.baseUrl}/books/add`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(book)
        });
        if (!res.ok) throw new Error(await res.text());
        return await res.json();
    },

    async getActiveLoans() {
        const res = await fetch(`${this.baseUrl}/loans/active`, { cache: 'no-store' });
        return await res.json();
    },

    async getOverdueLoans() {
        const res = await fetch(`${this.baseUrl}/loans/overdue`, { cache: 'no-store' });
        return await res.json();
    },

    async borrowBook(bookId, memberId) {
        const res = await fetch(`${this.baseUrl}/loans/borrow`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bookId, memberId })
        });
        if (!res.ok) throw new Error(await res.text());
        return await res.json();
    },

    async returnBook(bookId, memberId) {
        const res = await fetch(`${this.baseUrl}/loans/return`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bookId, memberId })
        });
        if (!res.ok) throw new Error(await res.text());
        return await res.json();
    },

    async updateBook(book) {
        const res = await fetch(`${this.baseUrl}/books`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(book)
        });
        if (!res.ok) throw new Error(await res.text());
        return await res.json();
    },

    async updateProfile(id, name, surname, password, avatarUrl) {
        const res = await fetch(`${this.baseUrl}/profile`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, name, surname, password, avatarUrl })
        });
        if (!res.ok) throw new Error(await res.text());
        return res.json();
    },

    async updateUser(id, name, surname, password, avatarUrl) {
        const res = await fetch(`${this.baseUrl}/users/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, surname, password, avatarUrl }) // API expects ProfileUpdateRequest
        });
        if (!res.ok) throw new Error(await res.text());
        return res.json();
    },

    async addMember(name, surname, password) {
        const res = await fetch(`${this.baseUrl}/users`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, surname, password })
        });
        if (!res.ok) throw new Error(await res.text());
        return res.json();
    },

    async getMembers() {
        const res = await fetch(`${this.baseUrl}/users`, { cache: 'no-store' });
        return await res.json();
    },

    async deleteUser(id) {
        const res = await fetch(`${this.baseUrl}/users/${id}`, {
            method: 'DELETE'
        });
        if (!res.ok) throw new Error(await res.text());
        return await res.json();
    },

    async deleteBook(id) {
        const res = await fetch(`${this.baseUrl}/books/${id}`, {
            method: 'DELETE'
        });
        if (!res.ok) throw new Error(await res.text());
        return await res.json();
    }
};
