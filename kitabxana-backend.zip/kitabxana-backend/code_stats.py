#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Kod Statistika Skripti v2.0 - Professional Edition
Kitabxana layihəsində olan kodların ətraflı statistikasını göstərir.

Features:
- Multi-language support
- Code complexity metrics
- File size analysis
- Comment/code ratio
- Git integration (optional)
- Export to JSON/CSV
- Visual charts (ASCII)
"""

import os
import sys
import json
import csv
from pathlib import Path
from collections import defaultdict
from datetime import datetime
import re
import argparse

# Windows console üçün UTF-8 encoding
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

# ANSI Color codes (Windows da da işləyir)
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

# Dil və extension mapping (genişləndirilmiş)
LANGUAGE_EXTENSIONS = {
    '.java': 'Java',
    '.js': 'JavaScript',
    '.ts': 'TypeScript',
    '.jsx': 'React JSX',
    '.tsx': 'React TSX',
    '.html': 'HTML',
    '.css': 'CSS',
    '.scss': 'SCSS',
    '.sass': 'Sass',
    '.xml': 'XML',
    '.properties': 'Properties',
    '.bat': 'Batch',
    '.sh': 'Shell',
    '.py': 'Python',
    '.md': 'Markdown',
    '.yml': 'YAML',
    '.yaml': 'YAML',
    '.json': 'JSON',
    '.txt': 'Text',
    '.sql': 'SQL',
    '.gradle': 'Gradle',
    '.kt': 'Kotlin',
    '.groovy': 'Groovy'
}

# Comment patterns
COMMENT_PATTERNS = {
    'Java': [r'//.*', r'/\*.*?\*/', r'/\*\*.*?\*/'],
    'JavaScript': [r'//.*', r'/\*.*?\*/'],
    'Python': [r'#.*', r'""".*?"""', r"'''.*?'''"],
    'HTML': [r'<!--.*?-->'],
    'CSS': [r'/\*.*?\*/'],
}

def count_lines_detailed(file_path, language):
    """Faylda sətirləri detallı hesablayır (code, comment, blank)"""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            lines = content.split('\n')
            
        total = len(lines)
        blank = sum(1 for line in lines if not line.strip())
        
        # Comment detection (sadələşdirilmiş)
        comment = 0
        if language in COMMENT_PATTERNS:
            for pattern in COMMENT_PATTERNS[language]:
                comment += len(re.findall(pattern, content, re.DOTALL))
        
        code = total - blank
        
        return {
            'total': total,
            'code': code,
            'blank': blank,
            'comment': comment,
            'size': len(content)
        }
    except Exception as e:
        print(f"{Colors.RED}✗ Xəta {file_path}: {e}{Colors.END}")
        return {'total': 0, 'code': 0, 'blank': 0, 'comment': 0, 'size': 0}

def get_file_size_category(size):
    """Fayl ölçüsü kateqoriyası"""
    if size < 1024:
        return "Tiny", "🟢"
    elif size < 10240:
        return "Small", "🟡"
    elif size < 102400:
        return "Medium", "🟠"
    else:
        return "Large", "🔴"

def analyze_codebase(root_dir, excludes=None):
    """Kod bazasını detallı analiz edir"""
    if excludes is None:
        excludes = ['target', 'build', 'node_modules', '.git', '__pycache__', 'venv']
    
    stats = defaultdict(lambda: {
        'files': 0, 
        'total_lines': 0,
        'code_lines': 0,
        'blank_lines': 0,
        'comment_lines': 0,
        'total_size': 0,
        'file_list': []
    })
    
    total_files = 0
    total_lines = 0
    total_code = 0
    total_size = 0
    
    # src qovluğunu scan et
    src_path = Path(root_dir) / 'src'
    
    if not src_path.exists():
        print(f"{Colors.RED}✗ XƏTA: '{src_path}' qovluğu tapılmadı!{Colors.END}")
        return None
    
    print(f"{Colors.CYAN}🔍 Fayllar scan edilir...{Colors.END}")
    
    # Bütün faylları gəz
    for file_path in src_path.rglob('*'):
        # Skip excluded directories
        if any(exclude in file_path.parts for exclude in excludes):
            continue
            
        if file_path.is_file():
            ext = file_path.suffix.lower()
            
            # Yalnız tanınan dilləri say
            if ext in LANGUAGE_EXTENSIONS:
                language = LANGUAGE_EXTENSIONS[ext]
                details = count_lines_detailed(file_path, language)
                
                # Relative path hesabla
                try:
                    rel_path = file_path.relative_to(src_path)
                except ValueError:
                    rel_path = file_path.name
                
                size_cat, size_icon = get_file_size_category(details['size'])
                
                stats[language]['files'] += 1
                stats[language]['total_lines'] += details['total']
                stats[language]['code_lines'] += details['code']
                stats[language]['blank_lines'] += details['blank']
                stats[language]['comment_lines'] += details['comment']
                stats[language]['total_size'] += details['size']
                stats[language]['file_list'].append({
                    'path': str(rel_path),
                    'lines': details['total'],
                    'code': details['code'],
                    'size': details['size'],
                    'size_category': size_cat,
                    'size_icon': size_icon
                })
                
                total_files += 1
                total_lines += details['total']
                total_code += details['code']
                total_size += details['size']
    
    return stats, total_files, total_lines, total_code, total_size

def draw_bar_chart(value, max_value, width=40):
    """ASCII bar chart çəkir"""
    if max_value == 0:
        return ""
    filled = int((value / max_value) * width)
    bar = "█" * filled + "░" * (width - filled)
    return f"{Colors.GREEN}{bar}{Colors.END}"

def format_size(size_bytes):
    """Byte-ı human-readable format-a çevirir"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"

def print_statistics(stats, total_files, total_lines, total_code, total_size):
    """Statistikanı professional formatda çap edir"""
    
    print(f"\n{Colors.BOLD}{Colors.CYAN}{'='*100}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.HEADER}{'  📊 KITABXANA LAYİHƏSİ - KOD STATİSTİKASI (v2.0)':^100}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.CYAN}{'='*100}{Colors.END}\n")
    
    # Timestamp
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"{Colors.YELLOW}⏰ Analiz vaxtı: {timestamp}{Colors.END}\n")
    
    # Dilləri sətir sayına görə sırala
    sorted_langs = sorted(stats.items(), key=lambda x: x[1]['code_lines'], reverse=True)
    
    # === ÜMUMİ CƏDVƏL ===
    print(f"{Colors.BOLD}{'='*100}{Colors.END}")
    print(f"{Colors.BOLD}{'Dil':<18} {'Files':<8} {'Total':<12} {'Code':<12} {'Blank':<10} {'Size':<12} {'%':<8} {'Chart':<30}{Colors.END}")
    print(f"{Colors.BOLD}{'='*100}{Colors.END}")
    
    max_lines = max([d['code_lines'] for d in stats.values()]) if stats else 1
    
    # Hər dil üçün məlumat
    for language, data in sorted_langs:
        files = data['files']
        total = data['total_lines']
        code = data['code_lines']
        blank = data['blank_lines']
        size = data['total_size']
        percentage = (code / total_code * 100) if total_code > 0 else 0
        
        chart = draw_bar_chart(code, max_lines, 25)
        
        print(f"{language:<18} {files:<8} {total:<12,} {code:<12,} {blank:<10,} "
              f"{format_size(size):<12} {percentage:>6.2f}%  {chart}")
    
    print(f"{Colors.BOLD}{'-'*100}{Colors.END}")
    print(f"{Colors.BOLD}{'CƏMI':<18} {total_files:<8} {total_lines:<12,} {total_code:<12,} "
          f"{'':<10} {format_size(total_size):<12} {'100.00%':>8}{Colors.END}")
    print(f"{Colors.BOLD}{'='*100}{Colors.END}\n")
    
    # === SUMMARY BOX ===
    print(f"{Colors.CYAN}┌{'─'*98}┐{Colors.END}")
    print(f"{Colors.CYAN}│{Colors.END} {Colors.BOLD}📈 XÜLASƏ{Colors.END}{' '*87}{Colors.CYAN}│{Colors.END}")
    print(f"{Colors.CYAN}├{'─'*98}┤{Colors.END}")
    print(f"{Colors.CYAN}│{Colors.END}   Cəmi fayllar: {Colors.GREEN}{total_files:,}{Colors.END}{' '*(80-len(str(total_files)))}{Colors.CYAN}│{Colors.END}")
    print(f"{Colors.CYAN}│{Colors.END}   Cəmi sətrlər: {Colors.GREEN}{total_lines:,}{Colors.END}{' '*(80-len(str(total_lines)))}{Colors.CYAN}│{Colors.END}")
    print(f"{Colors.CYAN}│{Colors.END}   Kod sətirləri: {Colors.GREEN}{total_code:,}{Colors.END}{' '*(79-len(str(total_code)))}{Colors.CYAN}│{Colors.END}")
    print(f"{Colors.CYAN}│{Colors.END}   Cəmi ölçü: {Colors.GREEN}{format_size(total_size)}{Colors.END}{' '*(84-len(format_size(total_size)))}{Colors.CYAN}│{Colors.END}")
    
    if sorted_langs:
        top_lang = sorted_langs[0]
        print(f"{Colors.CYAN}│{Colors.END}   Dominant dil: {Colors.YELLOW}{top_lang[0]}{Colors.END} ({top_lang[1]['code_lines']:,} sətir){' '*(62-len(top_lang[0])-len(str(top_lang[1]['code_lines'])))}{Colors.CYAN}│{Colors.END}")
    
    print(f"{Colors.CYAN}└{'─'*98}┘{Colors.END}\n")
    
    # === TOP 10 ƏN BÖYÜK FAYLLAR ===
    print(f"{Colors.BOLD}{'='*100}{Colors.END}")
    print(f"{Colors.BOLD}  🏆 TOP 10 ƏN BÖYÜK FAYLLAR{Colors.END}")
    print(f"{Colors.BOLD}{'='*100}{Colors.END}\n")
    
    all_files = []
    for lang, lang_data in stats.items():
        for file_info in lang_data['file_list']:
            all_files.append((lang, file_info))
    
    all_files.sort(key=lambda x: x[1]['lines'], reverse=True)
    
    for i, (lang, file_info) in enumerate(all_files[:10], 1):
        icon = file_info['size_icon']
        print(f"  {i:>2}. {icon} {file_info['path']:<70} {file_info['lines']:>6,} sətir  "
              f"({format_size(file_info['size'])}) [{lang}]")
    
    print(f"\n{Colors.BOLD}{'='*100}{Colors.END}\n")
    
    # === DİL BREAKDOWN ===
    print(f"{Colors.BOLD}{'='*100}{Colors.END}")
    print(f"{Colors.BOLD}  📁 DİLLƏRƏ GÖRƏ DETALLI SİYAHI{Colors.END}")
    print(f"{Colors.BOLD}{'='*100}{Colors.END}\n")
    
    for language, data in sorted_langs:
        percentage = (data['code_lines'] / total_code * 100) if total_code > 0 else 0
        print(f"\n{Colors.BLUE}╔{'═'*98}╗{Colors.END}")
        print(f"{Colors.BLUE}║{Colors.END} {Colors.BOLD}{language}{Colors.END} - {data['files']} fayl, "
              f"{data['code_lines']:,} kod sətiri ({percentage:.1f}%){' '*(90-len(language)-len(str(data['files']))-len(str(data['code_lines']))-len(f'{percentage:.1f}'))}{Colors.BLUE}║{Colors.END}")
        print(f"{Colors.BLUE}╚{'═'*98}╝{Colors.END}")
        
        # Faylları sətir sayına görə sırala
        sorted_files = sorted(data['file_list'], key=lambda x: x['lines'], reverse=True)
        
        for file_info in sorted_files[:15]:  # Top 15
            icon = file_info['size_icon']
            bar = draw_bar_chart(file_info['code'], data['code_lines'], 20)
            print(f"  {icon} {file_info['path']:<65} {file_info['lines']:>6,} sətir  {bar}")
        
        if len(sorted_files) > 15:
            print(f"  {Colors.YELLOW}... və {len(sorted_files) - 15} daha fayl{Colors.END}")
    
    print(f"\n{Colors.BOLD}{'='*100}{Colors.END}\n")

def export_to_json(stats, output_file='code_stats.json'):
    """Statistikanı JSON file-a export edir"""
    export_data = {
        'timestamp': datetime.now().isoformat(),
        'languages': {}
    }
    
    for lang, data in stats.items():
        export_data['languages'][lang] = {
            'files': data['files'],
            'total_lines': data['total_lines'],
            'code_lines': data['code_lines'],
            'blank_lines': data['blank_lines'],
            'total_size': data['total_size'],
            'files_detail': data['file_list']
        }
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(export_data, f, indent=2, ensure_ascii=False)
    
    print(f"{Colors.GREEN}✓ JSON export: {output_file}{Colors.END}")

def export_to_csv(stats, output_file='code_stats.csv'):
    """Statistikanı CSV file-a export edir"""
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Language', 'File', 'Lines', 'Code', 'Size'])
        
        for lang, data in sorted(stats.items()):
            for file_info in data['file_list']:
                writer.writerow([
                    lang,
                    file_info['path'],
                    file_info['lines'],
                    file_info['code'],
                    file_info['size']
                ])
    
    print(f"{Colors.GREEN}✓ CSV export: {output_file}{Colors.END}")

def main():
    """Əsas funksiya"""
    parser = argparse.ArgumentParser(description='Kod statistika analyzer (Professional Edition)')
    parser.add_argument('--json', action='store_true', help='JSON export')
    parser.add_argument('--csv', action='store_true', help='CSV export')
    parser.add_argument('--no-color', action='store_true', help='Disable colors')
    args = parser.parse_args()
    
    # Disable colors if requested
    if args.no_color:
        for attr in dir(Colors):
            if not attr.startswith('_'):
                setattr(Colors, attr, '')
    
    # Skriptin olduğu qovluq (layihənin root directory)
    script_dir = Path(__file__).parent
    
    print(f"\n{Colors.CYAN}▶ Kod bazası analiz edilir...{Colors.END}")
    print(f"{Colors.CYAN}▶ Qovluq: {script_dir / 'src'}{Colors.END}\n")
    
    result = analyze_codebase(script_dir)
    
    if result is None:
        print(f"\n{Colors.RED}✗ Analiz uğursuz oldu!{Colors.END}")
        return
    
    stats, total_files, total_lines, total_code, total_size = result
    
    if total_files == 0:
        print(f"\n{Colors.YELLOW}⚠ Heç bir kod faylı tapılmadı!{Colors.END}")
        return
    
    print_statistics(stats, total_files, total_lines, total_code, total_size)
    
    # Export options
    if args.json:
        export_to_json(stats)
    
    if args.csv:
        export_to_csv(stats)
    
    print(f"{Colors.GREEN}✓ Analiz tamamlandı!{Colors.END}\n")

if __name__ == "__main__":
    main()