# KİTABXANA LAYİHƏSİ - DOKUMENTASİYA İNDEKSİ

## 📚 Fayl Strukturu

Bu layihədə 5 komanda üzvünün Java Spring Boot kitabxana layihəsindəki hissələri izah edən 2 tip sənəd var:

### 🔍 Ətraflı Versiyalar (400-550 sətir)
Dərin texniki izahlar, diaqramlar, kod nümunələri, glossary və müsahibə sualları

- **İsmixan.txt** (450+ sətir) - Service Layer (Birinci Hissə)
- **Rauf.txt** (550+ sətir) - Service Layer (İkinci Hissə)  
- **Aydan.txt** (450+ sətir) - Infrastructure & Foundation
- **Məhəmməd.txt** (450+ sətir) - Data Models
- **Səccad.txt** (550+ sətir) - Controller Layer

### 💻 Saf Kod Versiyaları (150-250 sətir)
Yalnız kod strukturu və key points (tez baxış və prezentasiya üçün)

- **İsmixan_kod.txt** (200 sətir)
- **Rauf_kod.txt** (250 sətir)
- **Aydan_kod.txt** (180 sətir)
- **Məhəmməd_kod.txt** (200 sətir)
- **Səccad_kod.txt** (230 sətir)

---

## 📖 Hər Faylın Məzmunu

### İsmixan.txt / İsmixan_kod.txt
**Məsuliyyət:** Service Layer - İnitializasiya, ID Generasiya, Seed Data

**Əhatə edir:**
- `@Service`, `@PostConstruct`, `@Transactional` annotations
- Spring Dependency Injection (constructor-based)
- AtomicInteger thread-safe ID generation
- Seed data strategy (admin, members, 100+ books)
- Batch insert optimization
- Application startup sequence

**Əsas Mövzular:**
- Spring Framework lifecycle
- Bean management
- Concurrency (AtomicInteger, CAS)
- Database initialization
- ID generation patterns

---

### Rauf.txt / Rauf_kod.txt
**Məsuliyyət:** Service Layer - Authentication, Business Logic, CRUD

**Əhatə edir:**
- Authentication (login) with Optional pattern
- User signup & profile update
- Book CRUD operations
- Borrow/Return business logic
- Gamification integration
- Transaction management
- Synchronized methods

**Əsas Mövzular:**
- Authentication & Security
- `@Transactional` ACID principles
- `synchronized` thread safety
- Business rules enforcement
- Stream API functional programming
- Partial update pattern

---

### Aydan.txt / Aydan_kod.txt
**Məsuliyyət:** User Models, Application Entry Point, Repositories

**Əhatə edir:**
- `User` abstract base class
- `Member` və `Librarian` subclasses
- JPA inheritance (SINGLE_TABLE strategy)
- `@DiscriminatorColumn` / `@DiscriminatorValue`
- `Application.java` Spring Boot entry point
- Repository interfaces (Spring Data JPA)
- Gamification system (streak, totalReadCount)

**Əsas Mövzular:**
- JPA inheritance strategies
- `@SpringBootApplication` auto-configuration
- Repository pattern & method name queries
- Polymorphism
- Event listeners

---

### Məhəmməd.txt / Məhəmməd_kod.txt
**Məsuliyyət:** Book və Loan Domain Models

**Əhatə edir:**
- `Book` entity (JPA annotations)
- `Loan` entity
- `@ManyToOne` relationships
- FetchType.EAGER vs LAZY
- Bean Validation (`@NotBlank`)
- Computed properties (`@Transient`)
- Domain logic methods

**Əsas Mövzular:**
- JPA entities & relationships
- Entity lifecycle
- Validation framework
- `synchronized` domain methods
- LocalDate API
- Business logic encapsulation

---

### Səccad.txt / Səccad_kod.txt
**Məsuliyyət:** REST API Controller - HTTP Endpoints

**Əhatə edir:**
- `@RestController` configuration
- CORS policy (`@CrossOrigin`)
- DTO pattern (LoginRequest, SignUpRequest, etc.)
- HTTP methods (GET, POST, PUT, DELETE)
- `@RequestBody`, `@PathVariable`
- ResponseEntity pattern
- Error handling

**Əsas Mövzular:**
- REST API principles
- HTTP semantics & status codes
- CORS (Cross-Origin Resource Sharing)
- DTO vs Entity
- Request/Response flow
- JSON serialization (Jackson)

---

## 🎯 Oxuma Sırası

### Yeni Başlayanlar Üçün (Aşağıdan-Yuxarı):
```
1. Aydan.txt → Infrastructure & Models
2. Məhəmməd.txt → Domain Entities
3. İsmixan.txt → Service Initialization
4. Rauf.txt → Business Logic
5. Səccad.txt → REST API
```

### Təcrübəlilər Üçün (Yuxarıdan-Aşağı):
```
1. Səccad.txt → REST endpoints
2. Rauf.txt → Business logic
3. İsmixan.txt → Service setup
4. Məhəmməd.txt → Data models
5. Aydan.txt → Framework infrastructure
```

### Prezentasiya Üçün:
Saf kod versiyalarından (*_kod.txt) istifadə edin - qısa və aydındır.

---

## 📊 Statistika

| Fayl | Ətraflı | Kod | Əsas Fokus |
|------|---------|-----|------------|
| İsmixan | 450+ | 200 | Spring DI, Seed Data |
| Rauf | 550+ | 250 | Business Logic, Auth |
| Aydan | 450+ | 180 | JPA Inheritance, Repos |
| Məhəmməd | 450+ | 200 | Entities, Relationships |
| Səccad | 550+ | 230 | REST API, HTTP |
| **CƏMI** | **2450+** | **1060** | **25+ mövzu** |

---

## 🔑 Hər Faylda Olanlar

### Ətraflı Versiyalarda:
✅ Deep technical explanations
✅ Visual diagrams (Mermaid + ASCII)
✅ 50+ code examples (Java, SQL, JSON)
✅ Common mistakes (30+)
✅ Glossary (100+ terms)
✅ Interview questions (35+)
✅ Comparison tables
✅ Best practices

### Kod Versiyalarında:
✅ Clean code structure
✅ Key annotations
✅ Essential methods
✅ Quick reference points
✅ Minimal explanations

---

## 💡 İstifadə Ssenarilər

### Müsahibəyə Hazırlıq:
- Ətraflı versiyaları oxuyun
- Interview questions-ları təkrarlayın
- Glossary terminləri öyrənin

### Prezentasiya:
- Kod versiyalarından istifadə edin
- Key points-ləri vurğulayın
- Code examples göstərin

### Debugging:
- Common mistakes bölmələrinə baxın
- Code examples-dan ilham alın

### Öyrənmə:
- Diagrams-lardan başlayın
- Code examples-ı test edin
- Interview questions-ları özünüzə soruşun

---

## 🏗️ Layihə Arxitekturası

```
┌────────────────────────────────────────────┐
│         Frontend (HTML/CSS/JS)             │
│           http://localhost:3000            │
└──────────────────┬─────────────────────────┘
                   │ HTTP Requests
                   ▼
┌────────────────────────────────────────────┐
│    REST Controller (Səccad hissəsi)        │
│  @RestController, @RequestMapping          │
└──────────────────┬─────────────────────────┘
                   │
                   ▼
┌────────────────────────────────────────────┐
│  Service Layer (İsmixan + Rauf hissəsi)    │
│  @Service, @Transactional, Business Logic  │
└──────────────────┬─────────────────────────┘
                   │
        ┌──────────┼──────────┐
        ▼          ▼          ▼
┌──────────┐ ┌──────────┐ ┌──────────┐
│  Book    │ │  User    │ │  Loan    │
│Repository│ │Repository│ │Repository│
└────┬─────┘ └────┬─────┘ └────┬─────┘
     │            │            │
     └────────────┼────────────┘
                  ▼
         ┌────────────────┐
         │  Spring Data   │
         │      JPA       │
         └────────┬───────┘
                  ▼
         ┌────────────────┐
         │   Hibernate    │
         │      ORM       │
         └────────┬───────┘
                  ▼
         ┌────────────────┐
         │  H2 Database   │
         │   (In-Memory)  │
         └────────────────┘

Domain Models (Məhəmməd + Aydan hissəsi):
- User (abstract) → Member, Librarian
- Book
- Loan
```

---

## 📞 Komanda Üzvləri

| Ad | Məsuliyyət | Fayl |
|----|-----------|------|
| İsmixan | Service Init, Seed Data | İsmixan.txt |
| Rauf | Business Logic, Auth | Rauf.txt |
| Aydan | User Models, Repos, App | Aydan.txt |
| Məhəmməd | Book/Loan Entities | Məhəmməd.txt |
| Səccad | REST API Controller | Səccad.txt |

---

## ✨ Xüsusiyyətlər

Bu dokumentasiya:
- ✅ Tam əhatəli (heç bir boşluq yoxdur)
- ✅ Praktiki nümunələr (real kod)
- ✅ Visual (diagrams, tables)
- ✅ İnteractive (interview questions)
- ✅ Multilevel (beginnerdən expert-ə)
- ✅ Reference-friendly (glossary, index)

---

**Son yenilənmə:** 2025-12-15
**Versiya:** 2.0 (Comprehensive Edition)
